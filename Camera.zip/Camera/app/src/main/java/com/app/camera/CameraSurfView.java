package com.app.camera;
import android.view.SurfaceView;
import android.view.SurfaceHolder;

import android.content.Context;
import java.io.IOException;
import android.hardware.Camera;

public class CameraSurfView extends SurfaceView implements SurfaceHolder.Callback {
	private SurfaceHolder holder;
	private Camera camera;
	public CameraSurfView(Context context , Camera camer) {
		super(context);
		this.camera = camer;
		holder = getHolder();
		holder.addCallback(this);
		holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
	}
	@Override
	public void surfaceCreated(SurfaceHolder p1) {
		try {
			camera.setPreviewDisplay(p1);
			camera.startPreview();
		} catch (IOException e) {

		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder p1, int p2, int p3, int p4) {
		if (holder.getSurface() == null)
			return;
		try {
			camera.stopPreview();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			camera.setPreviewDisplay(holder);
			camera.startPreview();
		} catch (Exception e) {
			
		}

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder p1) {
	}




}
