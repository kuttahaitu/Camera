package com.app.camera;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.app.Activity;
import android.Manifest;
import android.hardware.Camera;
import android.media.MediaRecorder;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;

import android.view.View;
import android.widget.FrameLayout;
import java.io.File;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import java.io.FileOutputStream;
import android.widget.Toast;
import java.io.FileNotFoundException;
import java.io.IOException;
import android.media.CamcorderProfile;
import android.graphics.Matrix;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;
import android.os.Environment;

import android.media.MediaScannerConnection;
import android.net.Uri;
import java.util.Date;
import java.text.SimpleDateFormat;

public class MainActivity extends Activity {
	private static final String[] Req_permission={Manifest.permission.CAMERA,
	Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.RECORD_AUDIO};
	private static final int REQ_CODE=12;
	private static final int MEDIA_TYPE_IMG=1;
	private static final int MEDIA_TYPE_VID=2;
	private Camera camera;
	private CameraSurfView cameraview;
	private MediaRecorder mediaREC;
	private Button photo,video;
	private ImageButton capture,record,flip,play_pause_btn;
	private TextView textview_recording;
	private boolean isRecording=false;
	private boolean isPause=false;
	private boolean isback=true;
	private File vid_file;
    private FrameLayout preview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		ActivityCompat.requestPermissions(this,Req_permission,REQ_CODE);
		capture=findViewById(R.id.capture);
		record=findViewById(R.id.record);
		flip=findViewById(R.id.flip);
		photo=findViewById(R.id.photo);
		video=findViewById(R.id.video);
		textview_recording=findViewById(R.id.tv_rec);
		play_pause_btn=findViewById(R.id.pause_play_btn);
		if(!appPremissionGranted()){
			finish();
		}
		capture.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					camera.takePicture(null,null,Picture);
				}
				
			
		});
		record.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					if(isback)startRecording(Camera.CameraInfo.CAMERA_FACING_BACK);
					else startRecording(Camera.CameraInfo.CAMERA_FACING_FRONT);
				}

				});
		flip.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					flipCamera();
				}

				});
		
    }

	@Override
	protected void onResume() {
		super.onResume();
		if(isback)start(Camera.CameraInfo.CAMERA_FACING_BACK);
		else start(Camera.CameraInfo.CAMERA_FACING_FRONT);
	}
	
    private void start(int face){
		if(camera!=null){
			releaseCamera();
		}
		camera=getCameraInstance(face);
		cameraview=new CameraSurfView(this,camera);
		camera.setDisplayOrientation(90);
		preview=findViewById(R.id.camera_view);
		preview.addView(cameraview);
		capture.setVisibility(View.VISIBLE);
		record.setVisibility(View.INVISIBLE);
		photo.setTextColor(getColor(R.color.RED));
		video.setTextColor(getColor(R.color.black));
	}
	private void flipCamera(){
		if(isback){
			isback=false;
			start(Camera.CameraInfo.CAMERA_FACING_FRONT);
		}else{
			isback=true;
			start(Camera.CameraInfo.CAMERA_FACING_BACK);
		}
	}
	private Camera.PictureCallback Picture=new Camera.PictureCallback(){

		@Override
		public void onPictureTaken(byte[] p1, Camera camera) {
			camera.startPreview();
			File pic_file=getOutputMediaFile(MEDIA_TYPE_IMG);
			if(pic_file==null){
				return;
			}
			try{
				Bitmap image_bitmap=BitmapFactory.decodeByteArray(p1,0,p1.length);
				Camera.CameraInfo info=new Camera.CameraInfo();
				Camera.getCameraInfo(1,info);
				Bitmap bitmap;
				if(isback)bitmap=rotate(image_bitmap,90);
				else bitmap=rotate(image_bitmap,270);
				FileOutputStream fos=new FileOutputStream(pic_file);
				bitmap.compress(Bitmap.CompressFormat.JPEG,100,fos);
				Toast.makeText(MainActivity.this,"Image saved",Toast.LENGTH_LONG).show();
				fos.flush();
				fos.close();
				scanFile(pic_file.toString());
			}catch(FileNotFoundException e){
				
			}catch(IOException e){
				
			}
		}
		
		
	};
	private boolean prepareVideoRecorder(int face){
		vid_file=getOutputMediaFile(MEDIA_TYPE_VID);
		camera=getCameraInstance(face);
		camera.setDisplayOrientation(90);
		mediaREC=new MediaRecorder();
		if(isback)mediaREC.setOrientationHint(90);
		else mediaREC.setOrientationHint(270);
		camera.unlock();
		mediaREC.setCamera(camera);
		mediaREC.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
		mediaREC.setVideoSource(MediaRecorder.VideoSource.CAMERA);
		mediaREC.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH));
		mediaREC.setOutputFile(vid_file.toString());
		mediaREC.setPreviewDisplay(cameraview.getHolder().getSurface());
		try{
			mediaREC.prepare();
		}catch(IllegalStateException e){
			releaseMediaRecorder();
			return false;
		}catch(IOException e){
			releaseMediaRecorder();
			return false;
		}
		return true;
	}
	private void startRecording(int face){
		if(isRecording){
			mediaREC.stop();
			releaseMediaRecorder();
			camera.lock();
			Toast.makeText(this,"Video Saved",Toast.LENGTH_LONG).show();
			stopTimer();
			flip.setVisibility(View.VISIBLE);
			isRecording=false;
			scanFile(vid_file.toString());
		}else{
			if(prepareVideoRecorder(face)){
				Toast.makeText(this,"Recording Start",Toast.LENGTH_LONG).show();
				flip.setVisibility(View.INVISIBLE);
				mediaREC.start();
				startTimer();
				isRecording=true;
			}else{
				releaseMediaRecorder();
			}
		}
	}
	private void startTimer(){
		play_pause_btn.setVisibility(View.VISIBLE);
		play_pause_btn.setImageDrawable(getDrawable(R.drawable.ic_pause));
		isPause=false;
		textview_recording.setText("Recording....");
	}
	private void stopTimer(){
		play_pause_btn.setVisibility(View.INVISIBLE);
		isPause=false;
		textview_recording.setText("");
	}
	public void playPause(View view){
		if(!isPause){
			Toast.makeText(this,"Recording Pause",Toast.LENGTH_LONG).show();
			textview_recording.setText("Pause");
			mediaREC.pause();
			play_pause_btn.setImageDrawable(getDrawable(R.drawable.ic_play));
			isPause=true;
		}else{
			textview_recording.setText("Recording..");
			mediaREC.resume();
			play_pause_btn.setImageDrawable(getDrawable(R.drawable.ic_pause));
			isPause=false;
		}
	}
	public void switchMode(View view){
		if(view.getId()==R.id.photo){
			photo.setTextColor(getColor(R.color.RED));
			video.setTextColor(getColor(R.color.black));
			record.setVisibility(View.INVISIBLE);
			capture.setVisibility(View.VISIBLE);
		}else{
			photo.setTextColor(getColor(R.color.black));
			video.setTextColor(getColor(R.color.RED));
			record.setVisibility(View.VISIBLE);
			capture.setVisibility(View.INVISIBLE);
		}
	}
	private static Bitmap rotate(Bitmap bitmap,int degree){
		int width=bitmap.getWidth();
		int height=bitmap.getHeight();
		Matrix matrix=new Matrix();
		return Bitmap.createBitmap(bitmap,0,0,width,height,matrix,true);
	}
	private boolean appPremissionGranted(){
		boolean flag=true;
		for(int i=0;i<Req_permission.length;i++){
			if(ContextCompat.checkSelfPermission(this,Req_permission[i])!=
			PackageManager.PERMISSION_GRANTED)
			flag=false;
		}
		return flag;
	}
	public Camera getCameraInstance(int face){
		Camera cam=null;
		try{
			cam=Camera.open(face);
		}catch(Exception e){
			Toast.makeText(this,"Unable to open camera",Toast.LENGTH_LONG).show();
		}
		return cam;
	}
	private File getOutputMediaFile(int type){
		File mediaStorage_dir=new File(Environment.getExternalStoragePublicDirectory(
		Environment.DIRECTORY_PICTURES),"Camera");
		if(!mediaStorage_dir.exists())
			if(!mediaStorage_dir.mkdirs()){
				return null;
			}
			String timeStamp=new SimpleDateFormat("yyyyMMddd_HHmmss").format(new Date());
			File mediafile;
			if(type==MEDIA_TYPE_IMG)
				mediafile=new File(mediaStorage_dir.getPath()+File.separator+"IMG_"+timeStamp+".jpg");
			else if(type==MEDIA_TYPE_VID)
				mediafile=new File(mediaStorage_dir.getPath()+File.separator+"VID_"+timeStamp+".mp4");
			else
				return null;
		return mediafile;
	}
	private void scanFile(String file){
		MediaScannerConnection.scanFile(this,
		new String[]{file},null,
			new MediaScannerConnection.OnScanCompletedListener(){

				@Override
				public void onScanCompleted(String p1, Uri p2) {
				}
				
			
		});
	}
	private void releaseCamera(){
		if(camera!=null){
			camera.release();
			camera=null;
		}
	}
	private void releaseMediaRecorder(){
		if(mediaREC!=null){
			mediaREC.reset();
			mediaREC.release();
			mediaREC=null;
			camera.lock();
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		releaseCamera();
		releaseMediaRecorder();
	}
	
}

